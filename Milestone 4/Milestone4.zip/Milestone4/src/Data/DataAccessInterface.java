package Data;

import Models.User;

public interface DataAccessInterface {

	public boolean findBylogin(User user);
	
	public boolean Registration(User user);
	
}
