package Models;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

@ApplicationScoped
@ManagedBean
public class Product {
	
	int ID;
	String productName;
	String productDescription;
	double price;
	
	
	
	
	public Product() {
		this.ID = this.getID();
		this.productName = this.getProductName();
		this.productDescription = this.getProductDescription();
		this.price = this.getPrice();
		
	}

	public Product(int ID, String productName, String productDescription, double price) {
		this.ID = ID;
		this.productName = productName;
		this.productDescription = productDescription;
		this.price = price;
		
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
}
