package Models;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ViewScoped
@ManagedBean
public class SearchID {


	int ID;
	
	public SearchID() {
		this.ID = this.getID();
	}
	
	public SearchID(int ID) {
		this.ID = ID;
	}
	
	

	/**
	 * @return the iD
	 */
	public int getID() {
		return ID;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setID(int ID) {
		this.ID = ID;
	}
}
