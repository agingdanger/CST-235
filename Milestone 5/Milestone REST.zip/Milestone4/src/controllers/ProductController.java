package controllers;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import Business.ProductBusinessInterface;
import Models.Product;
import Models.User;

@ManagedBean
@ViewScoped
public class ProductController {

	@Inject
	ProductBusinessInterface pc;
	public List<Product> findAll()
	{
		List<Product> products = new ArrayList<>();
		products = pc.findAll();
		if(!pc.findAll().isEmpty())
		{
			return products;
		}
		else {
			System.out.println("There are no products!");
			return null;
		}
	}
	
	public Product findByID(int productID) {
		Product product = new Product();
		product = pc.findByID(productID);
		product.setID(product.getID());
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);
		return product;
	}
	
	public String updateProduct(Product product) {
		
		if(pc.updateProduct(product))
		return "AdminProduct.xhtml";
		else
			return "UpdateProduct.xhtml";
					
	}
	
	public String deleteProduct(Product product)
	{
		if(pc.deleteProduct(product))
			return "AdminProduct.xhtml";
			else
				return "UpdateProduct.xhtml";
	}
	
	
	public String newProduct(Product product)
	{
		if(pc.newProduct(product))
			return "AdminProduct.xhtml";
		else
			return "NewProduct.xhtml";
	}
}
